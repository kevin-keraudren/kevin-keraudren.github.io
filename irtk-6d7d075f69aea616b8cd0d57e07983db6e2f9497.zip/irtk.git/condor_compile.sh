condor_compile c++ $@

